/**
 * 
 */

(function () {
	/*
	 * private static field
	 */
	var ns = com.kang,
		_doc = window.document;
	
	
	/**
	 * constructor , instance fields
	 */
	ns.ButtonManager = function ButtonManager(editor) {
		this._editor = editor;
		
		_init(this);
	};
	/*
	 * private method
	 */
	function _init(thiz) {
		var defaultBtn =_doc.getElementsByClassName("btn"),
			dropBtn = _doc.getElementsByClassName("dropBtn");
			
			_btnSetAction(thiz,defaultBtn);
			_btnSetAction(thiz,dropBtn);
	};
	function _btnSetAction(thiz, btns,type) {
		for(var i=0, max=btns.length; i<max; ++i) {
			var btn = btns[i],
				type = "click";
			_addEventListner(thiz,btn, type);
		};
	};
	
	function _addEventListner(thiz,btn, type) {
		var useCapture = false,
			callback = _getBindedCallback(thiz, btn);
		
		btn.addEventListener(type, callback, useCapture);
	};
	function _getBindedCallback(thiz,btn) {
		//if(btn typeof
		var callback = function (e) {
			//crosBrowsing
			e = e || window.evnet;
			
			var target = e.target || e.srcElement,
				editor = thiz._editor,
				cmd = btn.id,
				param = null,
				data = [cmd, false, param];
			
			if(cmd == "fontSize" || "foreColor") {
				param = target.outerText;
				data[2] = param;
			}
			
			editor.updateStyle.apply(editor, data);
			editor.focus();
			
			//���������
			if(typeof e.preventDefault === 'function') {
				e.preventDefault();
				e.stopPropagation();
			} else {
				e.returnValue = false;
				e.cancelBubble = true;
			}
		};
		return callback;
	};
	
})();