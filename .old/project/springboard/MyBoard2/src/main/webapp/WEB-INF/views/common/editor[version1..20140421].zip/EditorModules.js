/**
 * 
 * WEB-INF/ ���� �̸� or
 * ���� HTML���� ��ġ�� ������� �̸�
 */
$$MODULE_NAMES = [
                  //my
                  "./part/IframeContentLoader.js",
                  "./part/ButtonManager.js",
                  "./part/NodeDecorator.js",
                  "Editor.js",
                  
                  //jasmine framework
                  "lib/jasmine-2.0.0/jasmine.js",
                  "lib/jasmine-2.0.0/jasmine-html.js",
                  "lib/jasmine-2.0.0/boot.js",
                  //testcase
                  "EditorTest.js",
                  "./part/ButtonManagerTest.js"
                  ,"./part/NodeDecoratorTest.js"
                  ];

