
/**
 * class Editor
 */

(function () {
	/*
	 * private static field
	 */
	var ns = com.kang,
		_doc = window.document;
	
	var DEFULAT_ID = "contentEditor";
	/**
	 * constructor , instance fields
	 */ 
	ns.Editor = function Editor(id) {
		this._id = id;
		this._contentDoc = _getContentDocOf(id); //�ʿ�� �����쳪 �ٸ����� �߰�
		this._btnManager = new ns.ButtonManager(this);
		this._nodeDecorator = ns.NodeDecorator;
		_init(this);
	};
	
	/*
	 * public method
	 */
	ns.Editor.prototype.updateStyle = function (cmd, bool, value) {
		this._contentDoc.execCommand(cmd, bool, value);
	};
	ns.Editor.prototype.focus = function() {
		var body = this._contentDoc.body;
		body.focus();
	};
	
	ns.Editor.prototype.decorateSelectedNode= function() {
		var doc = this._contentDoc,
			selection = doc.getSelection();
			rangeCount = selection.rangeCount;
			
		if(rangeCount) {
			var range = selection.getRangeAt(0);
			//this._nodeDecorator.decorateBy(range);
		};
		
	};
	
	
	/*
	 * prviate static method
	 */
	
	function _getContentDocOf(id) {
		if (!id) id = DEFULAT_ID;
		var iframe = document.getElementById(id);
		if(!(iframe)) throw id+"must be id of frame";
		
		var	contentDoc = iframe.contentWindow.document;
		return contentDoc;
	};
	
	function _init(thiz) {
		_contentInit(thiz);
		
	};
	
	function _contentInit(thiz) {
		thiz.focus();
	};

})();
