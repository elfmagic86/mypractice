/**
 * 
 */

describe("Editor", function() {
	var editor = new com.kang.Editor();
	window.test = editor;
	window.$disp = _disp;
	it("editor new initialize", function() {
		expect(editor).toBe(editor);
		/*expect(a).toEqual(b);*/
	});
	//���� ���õ� ��� �����ͼ� span�±׸� �θ�� �ֱ�.
	it("test",function () {
		var s = editor.decorateSelectedNode();
		
		/*var s = editor.getSeletedNode();
		console.log(s);*/
		
	});
});
function _disp(s) {
	for(var i in s) {
		if((typeof i) =="function") {
			var str = "function: " +i +"  : "+ s[i]();
			console.log(str);
		} else {
			var value = s[i];
/*			if(value.toString) {
				value = value.toString();
			}*/
			var field = "field :" + i + "  : "+ value;
			
		console.log(field);
		};
	};
};
