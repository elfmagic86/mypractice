/**
 * 
 */

(function () {
	/*
	 * private static field
	 */
	var ns = com.kang;
	
	ns.NodeDecorator = {
		
		decorateBy :  function(range) {
			var nodes = this._nodesInRange(range);
			return nodes;
		},
		_nodesInRange : function (range) {
		    var start = range.startContainer;
		    var end = range.endContainer;
		    var nodes = [];
		    var node;
		    
		    
		    
		    for (node = start; node; node = this._getNextNode(node))
		    {
		    	if(node.nodeType == 3)  
		    		nodes.push(node);
		        if (node == end)
		            break;
		    }

		    return nodes;
		},
		_getNextNode : function(node) {
		    if (node.firstChild)
		        return node.firstChild;
		    while (node)
		    {
		        if (node.nextSibling)
		            return node.nextSibling;
		        node = node.parentNode;
		    }
		},
		_hasOnlyOneChild: function (node) {
            var childNodes = node.childNodes;
            var childCount = childNodes.length;
            if (childCount > 3) {   // early return
                return _FALSE;
            }
            for (var i = 0, len = childCount; i < len; i++) {
                if ($tom.isGoogRangeCaret(childNodes[i])) {
                    childCount = childCount - 1;
                }
            }
            return childCount == 1;
        },
		
//				�����浹�� ���ƾ���.
				/*this._nodeDecorator.decorateNodes(nodes);
				surroundNode = _createNode();
				range.surroundContents(surroundNode);*/
				
	/*            var range = selection.getRangeAt(0);
	            var preSelectionRange = range.cloneRange();
	            preSelectionRange.selectNodeContents(doc.body);
	            preSelectionRange.setEnd(range.startContainer, range.startOffset);
	            start = preSelectionRange.toString().length;
	            end = start + range.toString().length;
				
	            var containerEl = doc.body;
		        var textRange = doc.body.createTextRange();
		        textRange.moveToElementText(containerEl);
		        textRange.collapse(true);
		        textRange.moveEnd("character", savedSel.end);
		        textRange.moveStart("character", savedSel.start);
		        textRange.select();*/
			
		_createNode : function (text) {
			var	span = document.createElement('span'),
				styleAttr = document.createAttribute('style'),
				nodeValue = "color: rgb(242, 150, 97);";
				styleAttr.nodeValue = nodeValue;	
				span.setAttributeNode(styleAttr);
				return span;
		}
	};
	
})();