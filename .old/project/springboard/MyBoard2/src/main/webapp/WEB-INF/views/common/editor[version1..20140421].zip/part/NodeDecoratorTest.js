/**
 * 
 */

describe("#resume", function() {
	var editor =new com.kang.Editor(),
		decor = com.kang.NodeDecorator;
	window.$editor = editor;
	window.$range = function() {return editor._contentDoc.getSelection().getRangeAt(0)};
	window.$decor = decor;	
		
	it("test", function() {
		//decor.decorateNodes(range);
	});
});